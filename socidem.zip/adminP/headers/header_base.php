<!DOCTYPE html> 
<html lang="en">

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Doccure - Login</title>
		
		 
        <link rel="shortcut icon" type="image/x-icon" href="adminP/assets/img/favicon.png">

	 
        <link rel="stylesheet" href="adminP/assets/css/bootstrap.min.css">
		
	 
        <link rel="stylesheet" href="adminP/assets/css/font-awesome.min.css">
	 
        <link rel="stylesheet" href="adminP/assets/css/feathericon.min.css">
		
		<link rel="stylesheet" href="adminP/assets/plugins/morris/morris.css">
	 
        <link rel="stylesheet" href="adminP/assets/css/style.css">
		
	 
    </head>