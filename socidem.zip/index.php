<?php
    require_once "controller/plantilla.controlador.php";
   

    $plantilla = new ControladorPlantilla();
    $plantilla -> ctrPlantilla();
