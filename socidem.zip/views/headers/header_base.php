<!DOCTYPE html> 
<html lang="en">

<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
		<title>Médicos en Directo</title>
		<link type="image/x-icon" href="views/assets/img/favicon.png" rel="icon">
	    <link rel="stylesheet" href="views/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="views/assets/plugins/fontawesome/css/fontawesome.min.css">
		<link rel="stylesheet" href="views/assets/plugins/fontawesome/css/all.min.css">
	    <link rel="stylesheet" href="views/assets/css/style.css">
</head>